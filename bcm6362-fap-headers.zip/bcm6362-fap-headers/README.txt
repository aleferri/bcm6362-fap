BCM6362 FAP - header di riferimento

Provenienza: bcm963xx__L__consumer_tar.gz (GPL tarball D-Link, profilo
DSL-3580_EU, BRCM_CHIP=6362). I percorsi interni sono quelli del tarball.
I file portano la licenza Broadcom "DUAL/GPL" (GPL v2 in assenza di un
accordo separato con Broadcom).

Dove guardare:

shared/opensource/include/bcm963xx/6362_map_part.h
    Mappa dei registri del SoC: CoprocCtlRegs_S (controllo FAP), DMARegs_S,
    DQM (DQMCtlRegs_S, DQMQCntrlRegs_S, DQMQDataRegs_S, DQMQMibRegs_S),
    Misc (miscFapIrqMask*), DmaRegs (iuDMA), indirizzi base PSM/QSM.
shared/opensource/include/bcm963xx/6362_intr.h
    Numeri di interrupt del controller periferico (FAP, ENETSW RX DMA).

bcmdrivers/broadcom/char/fap/impl1/fap_hw_6362.h
    Offset dei blocchi FAP, indirizzi lato 4KE e lato host, dimensioni
    PSM/QSM, struct Fap_FapInfo usata dal loader stock.
bcmdrivers/broadcom/char/fap/impl1/fap_hw_63268.h
    Stesso file per la famiglia 63268/63168 (due FAP), per confronto.
bcmdrivers/broadcom/char/fap/impl1/fap_dqm*.h, fap_dll.h, fap_packet.h,
fap_task.h, fap_tm.h, fap_dynmem.h, fap_slob.h
    Protocollo host<->FAP dello stock: code DQM, messaggi, pacchetti.
bcmdrivers/broadcom/char/fap/impl1/4ke/*.h
    Lato firmware 4KE: memoria (fap4ke_memory.h), interrupt (fap4ke_irq.h),
    mailbox, DQM, DMA interno (fap4ke_iopDma.h), timer, task.

bcmdrivers/opensource/include/bcm963xx/bcmPktDma*.h, fap.h
    Interfaccia usata dal driver ethernet stock verso iuDMA e verso il FAP
    (DQM). Le implementazioni corrispondenti sono in
    bcmdrivers/opensource/net/lib/pktdma/impl1/ nel tarball.
bcmdrivers/opensource/include/bcm963xx/bcm_map_part.h, bcm_intr.h,
bcmtypes.h
    Header di inclusione comuni richiesti dai precedenti.
