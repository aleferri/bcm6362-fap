BCM6362 FAP - reference headers

Origin: bcm963xx__L__consumer_tar.gz (D-Link GPL tarball, profile
DSL-3580_EU, BRCM_CHIP=6362). The internal paths are those of the tarball.
The files carry the Broadcom "DUAL/GPL" license (GPL v2 in the absence of a
separate agreement with Broadcom).

Where to look:

shared/opensource/include/bcm963xx/6362_map_part.h
    SoC register map: CoprocCtlRegs_S (FAP control), DMARegs_S,
    DQM (DQMCtlRegs_S, DQMQCntrlRegs_S, DQMQDataRegs_S, DQMQMibRegs_S),
    Misc (miscFapIrqMask*), DmaRegs (iuDMA), PSM/QSM base addresses.
shared/opensource/include/bcm963xx/6362_intr.h
    Peripheral interrupt controller numbers (FAP, ENETSW RX DMA).

bcmdrivers/broadcom/char/fap/impl1/fap_hw_6362.h
    FAP block offsets, 4KE-side and host-side addresses, PSM/QSM sizes,
    struct Fap_FapInfo used by the stock loader.
bcmdrivers/broadcom/char/fap/impl1/fap_hw_63268.h
    Same file for the 63268/63168 family (two FAPs), for comparison.
bcmdrivers/broadcom/char/fap/impl1/fap_dqm*.h, fap_dll.h, fap_packet.h,
fap_task.h, fap_tm.h, fap_dynmem.h, fap_slob.h
    Stock host<->FAP protocol: DQM queues, messages, packets.
bcmdrivers/broadcom/char/fap/impl1/4ke/*.h
    4KE firmware side: memory (fap4ke_memory.h), interrupts (fap4ke_irq.h),
    mailbox, DQM, internal DMA (fap4ke_iopDma.h), timers, tasks.

bcmdrivers/opensource/include/bcm963xx/bcmPktDma*.h, fap.h
    Interface used by the stock ethernet driver towards the iuDMA and the
    FAP (DQM). The corresponding implementations are in
    bcmdrivers/opensource/net/lib/pktdma/impl1/ in the tarball.
bcmdrivers/opensource/include/bcm963xx/bcm_map_part.h, bcm_intr.h,
bcmtypes.h
    Common include headers required by the above.
